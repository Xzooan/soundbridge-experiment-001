# SoundBridge Experiment 001

This is a physical-layer tone-detection experiment, NOT a file-transfer app yet.

## Test
1. Open in Android Studio; install Android SDK 35; sync Gradle.
2. Install on two Android phones.
3. On Phone B tap LISTEN and grant microphone permission.
4. On Phone A tap SEND TEST TONES.
5. Start at 1 metre, then test 3, 5 and 10 metres in a quiet room.
6. Record phone models, distance, orientation, volume and whether stable tone detection occurs.
7. Stop both tests. Keep volume moderate.

Phone A emits alternating 1200 Hz and 1800 Hz tones. Phone B samples at 48 kHz and uses Goertzel frequency-energy detection. No network, Bluetooth, Wi-Fi, hotspot, camera or external hardware is used.

## Limitations
- Detects tones only; does not transmit bytes/files.
- The receiver uses 4096-sample windows (~85 ms); audio processing varies by device.
- 10 m is a test target, not a guarantee.
- If microphone capture fails on a device, check permission and audio-source support.
- Not compiled or tested on physical phones in this environment.
