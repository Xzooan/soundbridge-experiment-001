package com.soundbridge.test

import android.Manifest
import android.content.pm.PackageManager
import android.media.*
import android.os.Bundle
import android.os.Process
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

class MainActivity:ComponentActivity(){
 private val rate=48000
 @Volatile private var sending=false
 @Volatile private var listening=false
 private var track:AudioTrack?=null
 private var recorder:AudioRecord?=null
 private lateinit var status:TextView
 private val permission=registerForActivityResult(ActivityResultContracts.RequestPermission()){if(it)listen()else show("Microphone permission denied")}
 override fun onCreate(savedInstanceState:Bundle?){
  super.onCreate(savedInstanceState)
  val root=LinearLayout(this).apply{orientation=1;setPadding(24,28,24,24);setBackgroundColor(0xFF101820.toInt())}
  setContentView(root)
  fun label(s:String,n:Float){root.addView(TextView(this).apply{text=s;textSize=n.toFloat();setTextColor(-1);gravity=Gravity.CENTER;setPadding(8,16,8,16)},lp())}
  label("SOUNDBRIDGE · EXPERIMENT 001",22f)
  label("Audible FSK signal detection · 48 kHz",14f)
  root.addView(Button(this).apply{text="PHONE A · SEND TEST TONES";setOnClickListener{if(sending)stopSend()else send()}},lp())
  root.addView(Button(this).apply{text="PHONE B · LISTEN";setOnClickListener{if(listening)stopListen()else if(ContextCompat.checkSelfPermission(this@MainActivity,Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)listen()else permission.launch(Manifest.permission.RECORD_AUDIO)}},lp())
  status=TextView(this).apply{text="Start listening on Phone B first, then send from Phone A.";textSize=16f;setTextColor(-1);setPadding(8,24,8,8)}
  root.addView(status,lp())
 }
 private fun send(){
  sending=true;show("Sending alternating 1200 Hz / 1800 Hz tones")
  thread{
   Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
   val min=AudioTrack.getMinBufferSize(rate,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT)
   val t=AudioTrack.Builder().setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()).setAudioFormat(AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()).setBufferSizeInBytes(maxOf(min,rate/2)).setTransferMode(AudioTrack.MODE_STREAM).build()
   track=t
   try{t.play();var bit=0;while(sending){val f=if(bit++%2==0)1200.0 else 1800.0;val n=rate*180/1000;val a=ShortArray(n){i->val env=minOf(1.0,i/240.0,(n-1-i)/240.0).coerceAtLeast(0.0);(sin(2*PI*f*i/rate)*env*10000).toInt().toShort()};t.write(a,0,a.size)}}catch(_:Exception){}
   finally{try{t.stop()}catch(_:Exception){};t.release();track=null}
  }
 }
 private fun stopSend(){sending=false;show("Sender stopped")}
 private fun listen(){
  listening=true;show("Listening for test tones…")
  thread{
   Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
   val min=AudioRecord.getMinBufferSize(rate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT)
   val r=AudioRecord(MediaRecorder.AudioSource.MIC,rate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,maxOf(min,rate));recorder=r
   try{r.startRecording();val buf=ShortArray(4096);while(listening){val n=r.read(buf,0,buf.size);if(n>1024){val a=power(buf,n,1200.0);val c=power(buf,n,1800.0);val sum=a+c+1e-9;val ratio=maxOf(a,c)/sum;val found=ratio>.62 && maxOf(a,c)>1e5;val msg=if(found)"Tone detected: ${if(a>c)"1200" else "1800"} Hz · ${(ratio*100).toInt()}% dominance" else "Listening… no confident tone";runOnUiThread{status.text=msg}}}}catch(e:Exception){runOnUiThread{status.text="Audio error: ${e.message}"}}finally{try{r.stop()}catch(_:Exception){};r.release();recorder=null}
  }
 }
 private fun power(x:ShortArray,n:Int,f:Double):Double{
  val k=(.5+n*f/rate).toInt();val w=2*PI*k/n;val coeff=2*cos(w);var q1=0.0;var q2=0.0
  for(i in 0 until n){val win=.5-.5*cos(2*PI*i/(n-1));val q0=x[i]*win+coeff*q1-q2;q2=q1;q1=q0}
  return q1*q1+q2*q2-coeff*q1*q2
 }
 private fun stopListen(){listening=false;show("Receiver stopped")}
 private fun show(s:String){runOnUiThread{status.text=s}}
 private fun lp()=LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT)
 override fun onDestroy(){sending=false;listening=false;super.onDestroy()}
}
