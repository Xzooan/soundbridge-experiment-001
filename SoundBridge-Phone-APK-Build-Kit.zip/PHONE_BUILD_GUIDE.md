# SoundBridge — phone-only APK build

No PC or Android Studio required. GitHub Actions compiles the APK in the cloud.

## Easiest mobile workflow
1. Extract this kit on your Android phone.
2. In Chrome, sign in at https://github.com and create a repository named `soundbridge-experiment-001` (public or private).
3. In the repository choose **Add file → Upload files**. Upload `SoundBridge-Experiment-001-Android.zip` from this kit and commit it to `main`.
4. In the repository choose **Add file → Create new file**. Name it exactly `.github/workflows/android-apk.yml`.
5. Open `BUILD_WORKFLOW.yml` from this kit, copy all its contents, paste them into the GitHub editor, then commit.
6. Open the **Actions** tab. Choose **Build SoundBridge APK** → **Run workflow** (or wait for the push-triggered build).
7. When the run finishes green, open it and download the `SoundBridge-debug-apk` artifact.
8. Extract the artifact ZIP and tap `app-debug.apk` to install. Android may ask you to permit installs from your browser/file manager. Allow only for this trusted file, then disable that permission again.

## Workflow file
The separate `BUILD_WORKFLOW.yml` in this kit is the exact content to paste into `.github/workflows/android-apk.yml`.

## Important
- GitHub needs internet for source upload and cloud build/download. The acoustic experiment between phones does not use internet.
- This is a debug/test APK, not a Play Store release.
- The app only detects alternating 1200 Hz / 1800 Hz tones. It does not transfer files yet.
- Source has not been compiled or device-tested here. A successful cloud build proves compilation only; actual two-phone acoustic performance still needs testing.
- If GitHub Actions reports an error, share the first red error from the build log.
